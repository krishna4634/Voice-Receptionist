"""Central configuration. Everything secret comes from environment variables / .env (never hard-coded)."""
import os
import secrets
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def _load_dotenv() -> None:
    """Tiny .env loader so we need no extra dependency. Real env vars win over the file."""
    path = ROOT / ".env"
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


_load_dotenv()
_DEV_SECRET = secrets.token_hex(32)  # random per process when SECRET_KEY is not set (dev only)


def _env(name: str, default: str = "") -> str:
    return os.environ.get(name, default)


class Settings:
    """Read lazily from the environment so tests can override values."""

    @property
    def env(self): return _env("APP_ENV", "development")
    @property
    def db_path(self): return _env("DB_PATH", str(ROOT / "data" / "app.db"))
    @property
    def secret_key(self): return _env("SECRET_KEY") or _DEV_SECRET
    @property
    def admin_username(self): return _env("ADMIN_USERNAME", "admin")
    @property
    def admin_password(self): return _env("ADMIN_PASSWORD") or ("admin123" if self.env != "production" else "")
    @property
    def token_ttl_minutes(self): return int(_env("TOKEN_TTL_MINUTES", "480"))
    @property
    def business_tz(self): return _env("BUSINESS_TZ", "Asia/Kolkata")
    @property
    def allowed_origins(self): return [o.strip() for o in _env("ALLOWED_ORIGINS", "").split(",") if o.strip()]
    # --- LLM ---
    @property
    def llm_provider(self): return _env("LLM_PROVIDER", "anthropic").lower()
    @property
    def anthropic_api_key(self): return _env("ANTHROPIC_API_KEY")
    @property
    def anthropic_model(self): return _env("ANTHROPIC_MODEL", "claude-haiku-4-5-20251001")
    @property
    def openai_api_key(self): return _env("OPENAI_API_KEY")
    @property
    def openai_base_url(self): return _env("OPENAI_BASE_URL", "https://api.groq.com/openai/v1")
    @property
    def openai_model(self): return _env("OPENAI_MODEL", "llama-3.3-70b-versatile")
    # --- automation ---
    @property
    def webhook_url(self): return _env("WEBHOOK_URL")
    @property
    def webhook_secret(self): return _env("WEBHOOK_SECRET")

    def validate(self) -> None:
        if self.env == "production":
            missing = [k for k in ("SECRET_KEY", "ADMIN_PASSWORD") if not _env(k)]
            if missing:
                raise RuntimeError(f"Missing required env vars in production: {', '.join(missing)}")
            if len(_env("SECRET_KEY")) < 32:
                raise RuntimeError("SECRET_KEY must be at least 32 characters")


settings = Settings()
