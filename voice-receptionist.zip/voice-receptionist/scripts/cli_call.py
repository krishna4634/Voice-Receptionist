"""Talk to the agent in the terminal (uses your real LLM key). Great for checking your setup quickly:
    python -m scripts.cli_call
"""
from app import agent, db, post_call


def main():
    db.init_db()
    with db.connect() as conn:
        call_id, _, greeting = agent.start_call(conn)
        print(f"[call {call_id}]\nAsha: {greeting}")
        while True:
            try:
                text = input("You: ").strip()
            except (EOFError, KeyboardInterrupt):
                break
            if text in ("/quit", "/end"):
                break
            call = db.row(conn, "SELECT * FROM calls WHERE id=?", (call_id,))
            r = agent.handle_turn(conn, call, text, event="speech" if text else "silence")
            conn.commit()
            print(f"Asha: {r['reply']}   {[a['tool'] + (' ok' if a['ok'] else ' FAILED') for a in r['actions']]}")
            if r["end_call"]:
                break
        result = post_call.finalize_call(conn, call_id)
        print("\nCall record:", {k: result[k] for k in ("status", "intent", "outcome", "lead_priority", "summary", "next_action")})


if __name__ == "__main__":
    main()
