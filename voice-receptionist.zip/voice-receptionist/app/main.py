"""FastAPI app: public caller endpoints (per-call token) + protected dashboard endpoints (admin login)."""
import logging
import os
from contextlib import asynccontextmanager
from typing import Literal, Optional

from fastapi import Depends, FastAPI, Header, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from . import agent, db, post_call, security
from .config import ROOT, settings
from .llm import llm_configured

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("app")


@asynccontextmanager
async def lifespan(_: FastAPI):
    settings.validate()
    db.init_db()
    if not llm_configured():
        log.warning("No LLM API key configured for provider '%s' - calls will fall back to 'technical problem' replies.",
                    settings.llm_provider)
    if settings.env != "production" and not os.environ.get("ADMIN_PASSWORD"):
        log.warning("Using default dev dashboard login admin / admin123. Set ADMIN_PASSWORD in .env.")
    yield


app = FastAPI(title="AI Voice Receptionist", lifespan=lifespan, docs_url="/docs" if settings.env != "production" else None,
              redoc_url=None, openapi_url="/openapi.json" if settings.env != "production" else None)
if settings.allowed_origins:
    app.add_middleware(CORSMiddleware, allow_origins=settings.allowed_origins, allow_methods=["GET", "POST", "PATCH"],
                       allow_headers=["Authorization", "Content-Type", "X-Call-Token"])


@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Permissions-Policy"] = "microphone=(self)"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
        "font-src https://fonts.gstatic.com; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'")
    if request.url.path.startswith("/api"):
        response.headers["Cache-Control"] = "no-store"  # transcripts/PII must never be cached
    return response


# ------------------------------------------------------------------ dependencies
def get_conn():
    with db.connect() as conn:
        yield conn


def client_ip(request: Request) -> str:
    fwd = request.headers.get("x-forwarded-for", "").split(",")[0].strip()
    return fwd or (request.client.host if request.client else "unknown")


def require_admin(authorization: Optional[str] = Header(default=None)) -> str:
    token = authorization[7:] if authorization and authorization.lower().startswith("bearer ") else ""
    user = security.verify_admin_token(token)
    if not user:
        raise HTTPException(401, "Not authenticated", headers={"WWW-Authenticate": "Bearer"})
    return user


def require_call(call_id: str, x_call_token: str = Header(default=""), conn=Depends(get_conn)) -> dict:
    call = db.row(conn, "SELECT * FROM calls WHERE id=?", (call_id,))
    if not call or not security.check_call_token(x_call_token, call["token_hash"]):
        raise HTTPException(401, "Invalid call credentials")
    return call


# ------------------------------------------------------------------ pages
@app.get("/", include_in_schema=False)
def caller_page():
    return FileResponse(ROOT / "static" / "index.html")


@app.get("/dashboard", include_in_schema=False)
def dashboard_page():
    return FileResponse(ROOT / "static" / "dashboard.html")


@app.get("/health")
def health():
    return {"status": "ok", "llm_configured": llm_configured(), "provider": settings.llm_provider}


# ------------------------------------------------------------------ caller (voice) API
class TurnIn(BaseModel):
    text: str = Field(default="", max_length=1000)
    event: Literal["speech", "silence", "unclear"] = "speech"
    interrupted: bool = False


@app.post("/api/calls")
def start_call(request: Request, conn=Depends(get_conn)):
    if not security.limiter.allow(f"start:{client_ip(request)}", 10, 60):
        raise HTTPException(429, "Too many calls started. Please wait a minute.")
    call_id, token, greeting = agent.start_call(conn)
    return {"call_id": call_id, "call_token": token, "greeting": greeting}


@app.post("/api/calls/{call_id}/turn")
def turn(body: TurnIn, call: dict = Depends(require_call), conn=Depends(get_conn)):
    if call["status"] != "active":
        raise HTTPException(409, "Call already ended")
    if not security.limiter.allow(f"turn:{call['id']}", 60, 60):
        raise HTTPException(429, "Slow down")
    return agent.handle_turn(conn, call, body.text, event=body.event, interrupted=body.interrupted)


@app.post("/api/calls/{call_id}/end")
def end_call(call: dict = Depends(require_call), conn=Depends(get_conn)):
    result = post_call.finalize_call(conn, call["id"])
    return {"call_id": call["id"], "status": result["status"], "outcome": result["outcome"], "summary": result["summary"]}


# ------------------------------------------------------------------ auth + dashboard API
class LoginIn(BaseModel):
    username: str = Field(max_length=100)
    password: str = Field(max_length=200)


@app.post("/api/auth/login")
def login(body: LoginIn, request: Request):
    if not security.limiter.allow(f"login:{client_ip(request)}", 5, 60):
        raise HTTPException(429, "Too many login attempts. Try again in a minute.")
    if not security.check_admin_credentials(body.username, body.password):
        raise HTTPException(401, "Wrong username or password")
    return {"token": security.make_admin_token(body.username), "expires_in_minutes": settings.token_ttl_minutes}


@app.get("/api/dashboard/stats")
def stats(admin: str = Depends(require_admin), conn=Depends(get_conn)):
    return db.dashboard_stats(conn)


@app.get("/api/dashboard/calls")
def calls(limit: int = 50, flag: Optional[Literal["followup", "escalated", "appointment"]] = None,
          admin: str = Depends(require_admin), conn=Depends(get_conn)):
    return db.list_calls(conn, limit, flag)


@app.get("/api/dashboard/calls/{call_id}")
def call_detail(call_id: str, admin: str = Depends(require_admin), conn=Depends(get_conn)):
    detail = db.call_detail(conn, call_id)
    if not detail:
        raise HTTPException(404, "Call not found")
    return detail


class FollowUpPatch(BaseModel):
    status: Literal["open", "done"]


@app.patch("/api/dashboard/follow-ups/{follow_up_id}")
def update_follow_up(follow_up_id: int, body: FollowUpPatch, admin: str = Depends(require_admin), conn=Depends(get_conn)):
    fu = db.row(conn, "SELECT * FROM follow_ups WHERE id=?", (follow_up_id,))
    if not fu:
        raise HTTPException(404, "Follow-up not found")
    db.update(conn, "follow_ups", follow_up_id, status=body.status)
    still_open = db.row(conn, "SELECT 1 AS x FROM follow_ups WHERE call_id=? AND status='open'", (fu["call_id"],))
    db.update(conn, "calls", fu["call_id"], needs_followup=1 if still_open else 0)
    return {"id": follow_up_id, "status": body.status}
