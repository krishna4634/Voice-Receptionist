import os
import unittest
from unittest import mock

import tests.helpers  # noqa: F401
from app import llm, tools

HISTORY = [
    {"role": "user", "content": "book me"},
    {"role": "assistant", "content": "", "tool_calls": [{"id": "t1", "name": "check_available_slots", "args": {"date": "2026-10-06"}},
                                                         {"id": "t2", "name": "create_lead", "args": {"name": "A"}}]},
    {"role": "tool", "tool_call_id": "t1", "name": "check_available_slots", "content": '{"ok": true}'},
    {"role": "tool", "tool_call_id": "t2", "name": "create_lead", "content": '{"ok": true}'},
]


class AnthropicAdapterTests(unittest.TestCase):
    def setUp(self):
        os.environ["ANTHROPIC_API_KEY"] = "k"
        self.addCleanup(os.environ.pop, "ANTHROPIC_API_KEY", None)

    def test_request_shape_and_response_parsing(self):
        reply = {"content": [{"type": "text", "text": "Checking."}, {"type": "tool_use", "id": "u1", "name": "create_lead", "input": {"name": "A"}}]}
        with mock.patch.object(llm, "_post", return_value=reply) as post:
            res = llm.AnthropicClient().complete("SYS", HISTORY, tools=tools.TOOL_SPECS)
        url, headers, payload = post.call_args[0]
        self.assertEqual(headers["x-api-key"], "k")
        self.assertEqual(payload["system"], "SYS")
        self.assertEqual(payload["tools"][0]["input_schema"]["type"], "object")
        msgs = payload["messages"]
        self.assertEqual([m["role"] for m in msgs], ["user", "assistant", "user"])
        self.assertEqual([b["type"] for b in msgs[1]["content"]], ["tool_use", "tool_use"])
        self.assertEqual([b["type"] for b in msgs[2]["content"]], ["tool_result", "tool_result"])  # grouped into ONE user turn
        self.assertEqual(res.text, "Checking.")
        self.assertEqual((res.tool_calls[0].name, res.tool_calls[0].args), ("create_lead", {"name": "A"}))

    def test_missing_key_raises_llm_error(self):
        os.environ.pop("ANTHROPIC_API_KEY")
        with self.assertRaises(llm.LLMError):
            llm.AnthropicClient()


class OpenAIAdapterTests(unittest.TestCase):
    def setUp(self):
        os.environ["OPENAI_API_KEY"] = "k"
        self.addCleanup(os.environ.pop, "OPENAI_API_KEY", None)

    def test_request_shape_and_response_parsing(self):
        reply = {"choices": [{"message": {"content": None, "tool_calls": [
            {"id": "c1", "function": {"name": "check_available_slots", "arguments": '{"date": "2026-10-06"}'}}]}}]}
        with mock.patch.object(llm, "_post", return_value=reply) as post:
            res = llm.OpenAICompatClient().complete("SYS", HISTORY, tools=tools.TOOL_SPECS)
        url, headers, payload = post.call_args[0]
        self.assertTrue(url.endswith("/chat/completions"))
        self.assertEqual(headers["Authorization"], "Bearer k")
        self.assertEqual(payload["messages"][0], {"role": "system", "content": "SYS"})
        self.assertEqual(payload["tools"][0]["type"], "function")
        asst = payload["messages"][2]
        self.assertEqual(asst["tool_calls"][0]["function"]["arguments"], '{"date": "2026-10-06"}')
        self.assertEqual([m["role"] for m in payload["messages"][3:]], ["tool", "tool"])
        self.assertEqual(res.tool_calls[0].args, {"date": "2026-10-06"})

    def test_malformed_tool_arguments_do_not_crash(self):
        reply = {"choices": [{"message": {"content": "", "tool_calls": [{"id": "c1", "function": {"name": "create_lead", "arguments": "{oops"}}]}}]}
        with mock.patch.object(llm, "_post", return_value=reply):
            res = llm.OpenAICompatClient().complete("S", [{"role": "user", "content": "x"}])
        self.assertEqual(res.tool_calls[0].args, {})

    def test_unexpected_payload_raises_llm_error(self):
        with mock.patch.object(llm, "_post", return_value={"error": "x"}):
            with self.assertRaises(llm.LLMError):
                llm.OpenAICompatClient().complete("S", [{"role": "user", "content": "x"}])


if __name__ == "__main__":
    unittest.main()
