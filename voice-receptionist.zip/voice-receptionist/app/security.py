"""Auth + abuse protection helpers (stdlib only)."""
import base64
import hashlib
import hmac
import json
import threading
import time
from collections import defaultdict, deque

from .config import settings


def _b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode().rstrip("=")


def _unb64(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def _sign(payload_b64: str) -> str:
    return _b64(hmac.new(settings.secret_key.encode(), payload_b64.encode(), hashlib.sha256).digest())


def make_admin_token(username: str) -> str:
    """Signed, expiring token (JWT-like). Verified with a constant-time compare."""
    payload = _b64(json.dumps({"sub": username, "exp": int(time.time()) + settings.token_ttl_minutes * 60}).encode())
    return f"{payload}.{_sign(payload)}"


def verify_admin_token(token: str):
    try:
        payload, sig = token.split(".", 1)
        if not hmac.compare_digest(sig, _sign(payload)):
            return None
        data = json.loads(_unb64(payload))
        return data["sub"] if data["exp"] > time.time() else None
    except Exception:
        return None


def check_admin_credentials(username: str, password: str) -> bool:
    expected_pw = settings.admin_password
    if not expected_pw:
        return False
    ok_user = hmac.compare_digest(username.encode(), settings.admin_username.encode())
    ok_pw = hmac.compare_digest(password.encode(), expected_pw.encode())
    return ok_user and ok_pw


def hash_token(token: str) -> str:
    """Call tokens are stored hashed, so a DB leak does not let anyone hijack a live call."""
    return hashlib.sha256(token.encode()).hexdigest()


def check_call_token(token: str, token_hash: str) -> bool:
    return bool(token) and hmac.compare_digest(hash_token(token), token_hash)


class RateLimiter:
    """Sliding-window limiter, in memory. Use Redis when running more than one server process."""

    def __init__(self):
        self.hits = defaultdict(deque)
        self.lock = threading.Lock()

    def allow(self, key: str, limit: int, window_s: int) -> bool:
        now = time.monotonic()
        with self.lock:
            q = self.hits[key]
            while q and now - q[0] > window_s:
                q.popleft()
            if len(q) >= limit:
                return False
            q.append(now)
            return True


limiter = RateLimiter()
