"""Business knowledge base + retrieval (RAG). Pure-Python BM25 over small chunks.

For a real deployment replace `KnowledgeBase.search` with embeddings + a vector store; the agent only
depends on the `search()` interface and on the relevance threshold below.
"""
import json
import math
import re
from collections import Counter
from functools import lru_cache
from pathlib import Path

from .config import ROOT

STOP = set("""a an the is are was were be to of in on at for and or but do does did you your i my me we our it this that
with can could would please tell about what which who how much many there any have has want need like get just
hello hi hey ok okay yes no so then also some""".split())


def _stem(w: str) -> str:
    """Very small stemmer: service/services/servicing -> servic, timing/times/time -> tim."""
    for suf in ("es", "s"):
        if w.endswith(suf) and len(w) - len(suf) >= 3:
            w = w[: -len(suf)]
            break
    for suf in ("ing", "ed"):
        if w.endswith(suf) and len(w) - len(suf) >= 3:
            w = w[: -len(suf)]
            break
    if w.endswith("e") and len(w) > 3:
        w = w[:-1]
    return w


def tokenize(text: str) -> list:
    return [_stem(w) for w in re.findall(r"[a-z0-9]+", text.lower()) if w not in STOP]


class KnowledgeBase:
    K1, B = 1.5, 0.75
    MIN_SCORE = 2.0  # below this we treat the question as "not covered" and never guess

    def __init__(self, chunks: list):
        self.chunks = chunks
        self.docs = [Counter(tokenize(f"{c['title']} {c['title']} {c.get('keywords', '')} {c['text']}")) for c in chunks]
        self.lens = [sum(d.values()) for d in self.docs]
        self.avg = sum(self.lens) / max(1, len(self.lens))
        df = Counter(t for d in self.docs for t in d)
        n = len(self.docs)
        self.idf = {t: math.log(1 + (n - f + 0.5) / (f + 0.5)) for t, f in df.items()}

    def search(self, query: str, k: int = 3) -> list:
        q = tokenize(query)
        scored = []
        for chunk, doc, length in zip(self.chunks, self.docs, self.lens):
            score = 0.0
            for t in set(q):
                tf = doc.get(t, 0)
                if tf:
                    score += self.idf[t] * tf * (self.K1 + 1) / (tf + self.K1 * (1 - self.B + self.B * length / self.avg))
            scored.append((score, chunk))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [{"id": c["id"], "title": c["title"], "text": c["text"], "score": round(s, 2)}
                for s, c in scored[:k] if s >= self.MIN_SCORE]


@lru_cache(maxsize=1)
def load_business() -> dict:
    return json.loads((ROOT / "data" / "business.json").read_text(encoding="utf-8"))


@lru_cache(maxsize=1)
def get_kb() -> KnowledgeBase:
    return KnowledgeBase(load_business()["chunks"])
