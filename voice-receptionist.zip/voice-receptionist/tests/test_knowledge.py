import unittest

from app.knowledge import get_kb


class KnowledgeTests(unittest.TestCase):
    def ids(self, q):
        return [h["id"] for h in get_kb().search(q)]

    def test_pricing_question_finds_pricing(self):
        self.assertEqual(self.ids("how much does AC servicing cost")[0], "price_ac")

    def test_hours_and_sunday(self):
        self.assertEqual(self.ids("do you work on sunday")[0], "hours")

    def test_service_area(self):
        self.assertEqual(self.ids("can you come to Whitefield")[0], "areas")

    def test_policy(self):
        self.assertEqual(self.ids("what is your cancellation policy")[0], "cancel")

    def test_unknown_question_returns_nothing_so_agent_cannot_guess(self):
        self.assertEqual(self.ids("what is the capital of France"), [])
        self.assertEqual(self.ids("tell me a joke about cats"), [])


if __name__ == "__main__":
    unittest.main()
