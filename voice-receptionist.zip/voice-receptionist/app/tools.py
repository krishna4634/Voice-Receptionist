"""Agent tools: real, validated backend actions the LLM can call.

Every tool returns a JSON-serialisable dict with `ok`. Failures return a machine-readable `error` plus a
`message` the LLM can turn into a natural spoken reply. All arguments are validated server-side because
they originate from an LLM (which in turn listens to an untrusted caller).
"""
import json
import re
import secrets
from datetime import date, datetime, time as dtime, timedelta

from . import clock, db
from .knowledge import load_business

OPEN_DAYS = {0, 1, 2, 3, 4, 5}      # Mon..Sat
OPEN_HOUR, CLOSE_HOUR = 9, 18       # last 1-hour slot starts at 17:00
HORIZON_DAYS = 14
MIN_LEAD = timedelta(hours=1)
URGENCIES = ("low", "medium", "high", "emergency")
FOLLOW_UP_TYPES = ("callback", "quote", "info_request", "complaint", "human_callback", "system_failure", "other")

# ------------------------------------------------------------------ tool schemas (given to the LLM)
TOOL_SPECS = [
    {"name": "check_available_slots",
     "description": "Check free one-hour appointment slots on a given date. Call this before offering any time to the caller.",
     "parameters": {"type": "object", "properties": {
         "date": {"type": "string", "description": "Date as YYYY-MM-DD (resolve words like 'tomorrow' using the current date in CALL STATE)"}},
         "required": ["date"]}},
    {"name": "book_appointment",
     "description": "Book a confirmed appointment. Only call after the caller has agreed to a specific slot and you have their name, phone number, service and locality.",
     "parameters": {"type": "object", "properties": {
         "customer_name": {"type": "string"},
         "phone": {"type": "string", "description": "10-digit Indian mobile number"},
         "service": {"type": "string", "description": "e.g. AC service, plumbing, deep cleaning"},
         "location": {"type": "string", "description": "Locality in Bengaluru, e.g. Koramangala"},
         "date": {"type": "string", "description": "YYYY-MM-DD"},
         "time": {"type": "string", "description": "24-hour HH:MM, must be one of the slots returned by check_available_slots"},
         "notes": {"type": "string"}},
         "required": ["customer_name", "phone", "service", "location", "date", "time"]}},
    {"name": "create_lead",
     "description": "Save the caller as a lead. Call as soon as you know their name, phone number and the service they want, and again later to update with location, urgency or preferred time.",
     "parameters": {"type": "object", "properties": {
         "name": {"type": "string"}, "phone": {"type": "string"}, "email": {"type": "string"},
         "service": {"type": "string"}, "location": {"type": "string"},
         "urgency": {"type": "string", "enum": list(URGENCIES)},
         "preferred_time": {"type": "string", "description": "Caller's preferred appointment/contact time in their own words"},
         "notes": {"type": "string"}},
         "required": ["name", "phone", "service"]}},
    {"name": "create_follow_up",
     "description": "Schedule a callback/follow-up task for the team, e.g. caller wants a quote, or you could not answer a question from the business information.",
     "parameters": {"type": "object", "properties": {
         "reason": {"type": "string", "description": "What the team needs to do and why"},
         "follow_up_type": {"type": "string", "enum": ["callback", "quote", "info_request", "other"]},
         "due_date": {"type": "string", "description": "Optional YYYY-MM-DD, default next business day"},
         "name": {"type": "string"}, "phone": {"type": "string"}},
         "required": ["reason"]}},
    {"name": "transfer_to_human",
     "description": "Escalate to a human team member. Use when the caller asks for a human, is upset or complains, asks for something unsupported, or you cannot resolve their need. This creates a high-priority callback and alerts the team; a live transfer is not available.",
     "parameters": {"type": "object", "properties": {
         "reason": {"type": "string"},
         "name": {"type": "string"}, "phone": {"type": "string"}},
         "required": ["reason"]}},
]


# ------------------------------------------------------------------ helpers
_WORD_DIGITS = {"zero": "0", "oh": "0", "one": "1", "two": "2", "three": "3", "four": "4",
                "five": "5", "six": "6", "seven": "7", "eight": "8", "nine": "9"}


def normalize_phone(raw):
    """Return +91XXXXXXXXXX for a valid Indian mobile number, else None."""
    if not raw:
        return None
    text = " ".join(_WORD_DIGITS.get(w, w) for w in str(raw).lower().split())
    digits = re.sub(r"\D", "", text)
    if len(digits) == 12 and digits.startswith("91"):
        digits = digits[2:]
    elif len(digits) == 11 and digits.startswith("0"):
        digits = digits[1:]
    return "+91" + digits if len(digits) == 10 and digits[0] in "6789" else None


def match_service_area(location):
    """Return the canonical service area for a free-text locality, or None."""
    loc = re.sub(r"[^a-z0-9 ]", " ", (location or "").lower())
    loc = " ".join(loc.split())
    for canonical, aliases in load_business()["service_areas"].items():
        if any(re.search(rf"\b{re.escape(a)}\b", loc) for a in aliases):
            return canonical
    return None


def _day_slots(d: date):
    if d.weekday() not in OPEN_DAYS:
        return []
    return [datetime.combine(d, dtime(h)) for h in range(OPEN_HOUR, CLOSE_HOUR)]


def free_slots(conn, d: date):
    now = clock.now_local()
    booked = {r["start_at"] for r in db.rows(
        conn, "SELECT start_at FROM appointments WHERE status='confirmed' AND start_at LIKE ?", (d.isoformat() + "%",))}
    return [s for s in _day_slots(d) if s >= now + MIN_LEAD and s.strftime("%Y-%m-%dT%H:%M") not in booked]


def next_available(conn, after: date, days=3):
    out, d = [], after
    for _ in range(HORIZON_DAYS):
        d += timedelta(days=1)
        slots = free_slots(conn, d)
        if slots:
            out.append({"date": d.isoformat(), "weekday": d.strftime("%A"),
                        "times": [s.strftime("%H:%M") for s in slots[:4]]})
        if len(out) >= days:
            break
    return out


def _parse_date(value):
    try:
        return date.fromisoformat(str(value).strip())
    except (ValueError, TypeError):
        return None


def _parse_slot(date_s, time_s):
    d = _parse_date(date_s)
    try:
        t = datetime.strptime(str(time_s).strip(), "%H:%M").time()
    except (ValueError, TypeError):
        return None
    return datetime.combine(d, t) if d else None


def _clean(value, limit=200):
    return re.sub(r"\s+", " ", str(value)).strip()[:limit] if value not in (None, "") else None


def upsert_customer(conn, call_id, name=None, phone=None, email=None, location=None):
    """Find by phone or create; attach to the call. Returns customer id (or None if nothing to save)."""
    now = clock.now_utc_iso()
    phone = normalize_phone(phone)
    call = db.row(conn, "SELECT customer_id FROM calls WHERE id=?", (call_id,))
    cust = db.row(conn, "SELECT * FROM customers WHERE phone=?", (phone,)) if phone else None
    if not cust and call and call["customer_id"]:
        cust = db.row(conn, "SELECT * FROM customers WHERE id=?", (call["customer_id"],))
    if cust:
        fields = {k: v for k, v in {"name": _clean(name, 80), "email": _clean(email, 120),
                                     "location": _clean(location, 120), "phone": phone or cust["phone"]}.items() if v}
        if fields:
            db.update(conn, "customers", cust["id"], updated_at=now, **fields)
        cid = cust["id"]
    elif name or phone or email:
        cid = db.insert(conn, "customers", name=_clean(name, 80), phone=phone, email=_clean(email, 120),
                        location=_clean(location, 120), created_at=now, updated_at=now)
    else:
        return None
    db.update(conn, "calls", call_id, customer_id=cid)
    return cid


def lead_priority(urgency, has_appointment, has_phone, has_location):
    if has_appointment or urgency in ("high", "emergency"):
        return "hot"
    return "warm" if has_phone and has_location else "cold"


def _next_business_day():
    d = clock.now_local().date() + timedelta(days=1)
    while d.weekday() not in OPEN_DAYS:
        d += timedelta(days=1)
    return d


# ------------------------------------------------------------------ tool implementations
def check_available_slots(conn, call_id, args):
    d = _parse_date(args.get("date"))
    if not d:
        return {"ok": False, "error": "invalid_date", "message": "Date must be YYYY-MM-DD. Ask the caller which day they prefer."}
    today = clock.now_local().date()
    if d < today or d > today + timedelta(days=HORIZON_DAYS):
        return {"ok": False, "error": "date_out_of_range",
                "message": f"We can only book from today up to {HORIZON_DAYS} days ahead."}
    slots = free_slots(conn, d)
    result = {"ok": True, "date": d.isoformat(), "weekday": d.strftime("%A"),
              "available_times": [s.strftime("%H:%M") for s in slots]}
    if not slots:
        result["message"] = "Closed on Sundays." if d.weekday() not in OPEN_DAYS else "No free slots that day."
        result["next_available"] = next_available(conn, d)
    return result


def book_appointment(conn, call_id, args):
    name, service = _clean(args.get("customer_name"), 80), _clean(args.get("service"), 80)
    phone, location = normalize_phone(args.get("phone")), _clean(args.get("location"), 120)
    missing = [k for k, v in (("customer_name", name), ("service", service), ("location", location)) if not v]
    if missing:
        return {"ok": False, "error": "missing_fields", "missing": missing, "message": "Ask the caller for the missing details."}
    if len(name) < 2:
        return {"ok": False, "error": "missing_fields", "missing": ["customer_name"], "message": "Ask for the caller's name."}
    if not phone:
        return {"ok": False, "error": "invalid_phone", "message": "Phone must be a valid 10-digit mobile number. Ask the caller to repeat it."}
    area = match_service_area(location)
    if not area:
        return {"ok": False, "error": "outside_service_area",
                "message": "Locality not in our service areas. Ask for the exact locality; if still outside, politely say we cannot serve it and offer a follow-up."}
    start = _parse_slot(args.get("date"), args.get("time"))
    if not start or start.minute != 0 or start.hour not in range(OPEN_HOUR, CLOSE_HOUR) or start.weekday() not in OPEN_DAYS:
        return {"ok": False, "error": "invalid_slot", "message": "Slots are hourly, Monday to Saturday, 9 AM to 5 PM start. Call check_available_slots first."}
    now = clock.now_local()
    if start < now + MIN_LEAD or start > now + timedelta(days=HORIZON_DAYS + 1):
        return {"ok": False, "error": "date_out_of_range", "message": "Slot is in the past, too soon (need 1 hour notice) or too far ahead."}

    cid = upsert_customer(conn, call_id, name=name, phone=phone, location=location)
    code = "BH-" + secrets.token_hex(3).upper()
    try:
        # the partial UNIQUE index guarantees no double booking even with concurrent calls
        appt_id = db.insert(conn, "appointments", call_id=call_id, customer_id=cid, service=service,
                            start_at=start.strftime("%Y-%m-%dT%H:%M"),
                            end_at=(start + timedelta(hours=1)).strftime("%Y-%m-%dT%H:%M"),
                            location=location, status="confirmed", confirmation_code=code, created_at=clock.now_utc_iso())
    except Exception as exc:
        if "UNIQUE" in str(exc).upper():
            return {"ok": False, "error": "slot_taken", "message": "That slot was just taken. Offer these alternatives.",
                    "alternatives": [s.strftime("%H:%M") for s in free_slots(conn, start.date())][:4]
                                    or next_available(conn, start.date())}
        raise
    # keep the lead in sync
    create_lead(conn, call_id, {"name": name, "phone": phone, "service": service, "location": location,
                                "preferred_time": start.strftime("%A %d %B, %I:%M %p"), "notes": _clean(args.get("notes"), 300)},
                _log=False, _appointment=True)
    return {"ok": True, "appointment_id": appt_id, "confirmation_code": code, "customer_name": name, "service": service,
            "location": location, "date": start.date().isoformat(),
            "spoken_time": start.strftime("%A %d %B at %I:%M %p").replace(" 0", " "), "duration": "1 hour"}


def create_lead(conn, call_id, args, _log=True, _appointment=False):
    name, phone, service = _clean(args.get("name"), 80), normalize_phone(args.get("phone")), _clean(args.get("service"), 80)
    if not (name and service):
        return {"ok": False, "error": "missing_fields", "message": "Need at least the caller's name and the service they want."}
    if not phone:
        return {"ok": False, "error": "invalid_phone", "message": "Phone must be a valid 10-digit mobile number. Ask the caller to repeat it."}
    urgency = args.get("urgency") if args.get("urgency") in URGENCIES else None
    cid = upsert_customer(conn, call_id, name=name, phone=phone, email=args.get("email"), location=args.get("location"))
    existing = db.row(conn, "SELECT * FROM leads WHERE call_id=?", (call_id,))
    has_appt = _appointment or bool(db.row(conn, "SELECT 1 AS x FROM appointments WHERE call_id=?", (call_id,)))
    merged = {k: _clean(args.get(k), 300) or (existing or {}).get(k)
              for k in ("location", "preferred_time", "notes")}
    merged["urgency"] = urgency or (existing or {}).get("urgency")
    merged["service"] = service
    priority = lead_priority(merged["urgency"], has_appt, True, bool(merged["location"]))
    status = "appointment_booked" if has_appt else "new"
    if existing:
        db.update(conn, "leads", existing["id"], customer_id=cid, priority=priority, status=status, **merged)
        lead_id = existing["id"]
    else:
        lead_id = db.insert(conn, "leads", call_id=call_id, customer_id=cid, priority=priority, status=status,
                            created_at=clock.now_utc_iso(), **merged)
    missing = [k for k in ("location", "urgency", "preferred_time") if not merged.get(k)]
    return {"ok": True, "lead_id": lead_id, "priority": priority, "still_missing": missing}


def create_follow_up(conn, call_id, args):
    reason = _clean(args.get("reason"), 400)
    if not reason:
        return {"ok": False, "error": "missing_fields", "message": "A reason is required."}
    cid = upsert_customer(conn, call_id, name=args.get("name"), phone=args.get("phone"))
    cust = db.row(conn, "SELECT phone FROM customers WHERE id=?", (cid,)) if cid else None
    if not (cust and cust["phone"]):
        return {"ok": False, "error": "need_phone", "message": "Ask for a callback number, then call this tool again with it."}
    ftype = args.get("follow_up_type") if args.get("follow_up_type") in FOLLOW_UP_TYPES else "callback"
    due = _parse_date(args.get("due_date")) or _next_business_day()
    if due < clock.now_local().date():
        due = _next_business_day()
    fid = db.insert(conn, "follow_ups", call_id=call_id, customer_id=cid, type=ftype, reason=reason,
                    due_date=due.isoformat(), status="open", created_at=clock.now_utc_iso())
    db.update(conn, "calls", call_id, needs_followup=1)
    return {"ok": True, "follow_up_id": fid, "due_date": due.isoformat(), "due_weekday": due.strftime("%A")}


def transfer_to_human(conn, call_id, args):
    from . import post_call  # local import avoids a circular dependency
    reason = _clean(args.get("reason"), 400) or "Caller needs a human"
    cid = upsert_customer(conn, call_id, name=args.get("name"), phone=args.get("phone"))
    cust = db.row(conn, "SELECT * FROM customers WHERE id=?", (cid,)) if cid else None
    has_phone = bool(cust and cust["phone"])
    existing = db.row(conn, "SELECT id FROM follow_ups WHERE call_id=? AND type='human_callback'", (call_id,))
    if existing:  # second call (e.g. after collecting the phone number): don't duplicate the escalation
        return {"ok": True, "already_escalated": True, "callback_number_on_file": has_phone,
                "message": "Escalation already created; the team will call back." if has_phone else "Ask for a callback number."}
    fid = db.insert(conn, "follow_ups", call_id=call_id, customer_id=cid, type="human_callback",
                    reason=f"ESCALATION: {reason}", due_date=clock.now_local().date().isoformat(),
                    status="open", created_at=clock.now_utc_iso())
    db.update(conn, "calls", call_id, escalated=1, needs_followup=1)
    post_call.notify(conn, call_id, "escalation", {"reason": reason, "customer": cust and {"name": cust["name"], "phone": cust["phone"]}})
    return {"ok": True, "follow_up_id": fid, "callback_number_on_file": has_phone,
            "message": "Escalation created and team alerted. A live transfer is not available; a human will call back."
                       if has_phone else "Escalation created, but no callback number yet. Ask for the number and call transfer_to_human again with phone."}


def system_follow_up(conn, call_id, reason):
    """Server-side safety net (not exposed to the LLM): create a follow-up even without a phone number."""
    call = db.row(conn, "SELECT customer_id FROM calls WHERE id=?", (call_id,))
    fid = db.insert(conn, "follow_ups", call_id=call_id, customer_id=call and call["customer_id"], type="system_failure",
                    reason=reason, due_date=_next_business_day().isoformat(), status="open", created_at=clock.now_utc_iso())
    db.update(conn, "calls", call_id, needs_followup=1)
    db.insert(conn, "agent_actions", call_id=call_id, tool="system_follow_up", arguments=json.dumps({"reason": reason}),
              result=json.dumps({"ok": True, "follow_up_id": fid}), success=1, created_at=clock.now_utc_iso())
    return fid


TOOLS = {"check_available_slots": check_available_slots, "book_appointment": book_appointment,
         "create_lead": create_lead, "create_follow_up": create_follow_up, "transfer_to_human": transfer_to_human}


def execute_tool(conn, call_id, name, args):
    """Run a tool, log it to agent_actions, and never raise (failures are returned to the LLM)."""
    args = args if isinstance(args, dict) else {}
    fn = TOOLS.get(name)
    try:
        if not fn:
            result = {"ok": False, "error": "unknown_tool", "message": f"No such tool: {name}"}
        else:
            conn.execute("SAVEPOINT tool")
            result = fn(conn, call_id, args)
            conn.execute("RELEASE tool")
    except Exception as exc:  # tool/API failure: roll back partial writes, tell the LLM to degrade gracefully
        try:
            conn.execute("ROLLBACK TO tool")
            conn.execute("RELEASE tool")
        except Exception:
            pass
        result = {"ok": False, "error": "tool_failure",
                  "message": "A system error occurred. Apologise briefly and offer to arrange a callback instead."}
        import logging
        logging.getLogger("tools").exception("tool %s failed: %s", name, exc)
    db.insert(conn, "agent_actions", call_id=call_id, tool=name, arguments=json.dumps(args, default=str),
              result=json.dumps(result, default=str), success=1 if result.get("ok") else 0, created_at=clock.now_utc_iso())
    return result
