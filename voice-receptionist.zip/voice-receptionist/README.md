# AI Voice Receptionist & Lead Qualification Agent

A browser-based voice agent ("Asha") for a sample home-services business (BrightHome Services, Bengaluru).
A caller talks to it; it answers from a business knowledge base, qualifies the lead, books appointments through
LLM tool calling, escalates to humans when needed, stores everything, and updates a staff dashboard.

## How it works

```
Browser (Chrome/Edge)                         FastAPI backend                           Storage / outputs
┌──────────────────────┐   text + event   ┌──────────────────────────────┐
│ Mic → Web Speech STT │ ───────────────► │ /api/calls/{id}/turn          │
│ barge-in + silence   │                  │  1. retrieve KB chunks (BM25) │          SQLite: customers, calls,
│ timer                │ ◄─────────────── │  2. LLM + tools (loop ≤5)     │ ───────► transcripts, leads, appointments,
│ Speech TTS ← reply   │   reply + actions│     check_available_slots     │          agent_actions, follow_ups,
└──────────────────────┘                  │     book_appointment          │          notifications
                                          │     create_lead / follow_up   │
 Dashboard (/dashboard) ◄── JWT-style ──► │     transfer_to_human         │ ──► webhook (HMAC-signed) to the team
                          token auth      │  3. persist transcript+actions│
                                          │ /end → call intelligence (LLM)│ ──► follow-up task + notifications
                                          └──────────────────────────────┘
```

## Quick start (local)

```bash
python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
pip install -r requirements-dev.txt
cp .env.example .env                 # Windows: copy .env.example .env   -> then edit .env
python -m pytest -q                  # run the tests
python -m scripts.seed_demo          # optional: sample calls so the dashboard is not empty
uvicorn app.main:app --reload
```

- Caller page: http://localhost:8000  (use **Chrome or Edge**; allow the microphone)
- Dashboard: http://localhost:8000/dashboard (login = `ADMIN_USERNAME` / `ADMIN_PASSWORD` from `.env`)
- Check your LLM key without the browser: `python -m scripts.cli_call`

**LLM key (pick one in `.env`):**
- `LLM_PROVIDER=anthropic` + `ANTHROPIC_API_KEY` (default model: Claude Haiku 4.5, fast and cheap for voice), or
- `LLM_PROVIDER=openai` with any OpenAI-compatible API. The defaults point to Groq (`OPENAI_BASE_URL`, `OPENAI_MODEL`), which has a free tier. Check their console for the current model names.

## Demo script (2 minutes)

1. "Hi, how much does AC servicing cost?" → answers from the knowledge base (₹599).
2. "I'd like to book a visit tomorrow morning. I'm Ravi, my number is 98450 12345, I'm in Koramangala." → asks missing info, checks slots, offers times.
3. "Ten AM is fine." → books it, reads back the confirmation code. The "What Asha did" panel shows the tool calls.
4. Ask something not in the KB ("Do you do solar panels?") → says it doesn't have that and offers a callback (no invented answer).
5. Say "I want to speak to a manager" → escalation + callback task.
6. Click **End call**, then open `/dashboard`: counts updated, open the call to see transcript, AI summary, actions, follow-ups, notifications.

## Requirement → where it is implemented

| # | Requirement | Where |
|---|---|---|
| 1 | Voice conversation: STT, LLM, TTS, multi-turn, silence/interruptions | `static/index.html` (Web Speech API, barge-in, silence timer), `app/agent.py` |
| 2 | Business knowledge / RAG, no invented answers | `data/business.json`, `app/knowledge.py` (BM25 + relevance threshold), prompt rules in `app/agent.py` |
| 3 | Lead qualification, persisted | `create_lead` in `app/tools.py`, tables `customers`, `leads` |
| 4 | LLM tool calling (not keyword routing) | `TOOL_SPECS` + loop in `app/agent.py`, adapters in `app/llm.py` |
| 5 | Appointment workflow with availability | `check_available_slots`, `book_appointment` (simulated calendar in DB, unique index prevents double booking) |
| 6 | Human escalation | `transfer_to_human` (explicit request, complaint, no info, repeated silence/misunderstanding) |
| 7 | Call intelligence | `app/post_call.py::finalize_call` (summary, requirement, intent, priority, outcome, next action, follow-up advice) |
| 8 | Internal dashboard | `static/dashboard.html`, `/api/dashboard/*` |
| 9 | Post-call automation | `post_call._automate`: lead → follow-up task → webhook; booking → team + customer confirmation (SMS simulated) |
| 10 | Backend & DB | `app/main.py`, `app/db.py` (7 persistent tables) |
| 11 | Failure handling | STT unsupported/denied → typed fallback; silence/unclear → reprompt → escalate; LLM retry → apology → system follow-up; tool crash contained and rolled back; slot taken → alternatives; webhook failure never breaks the call record |
| 12 | Security | env config, hashed per-call tokens, signed expiring admin tokens, rate limiting, input validation, CSP and security headers, XSS-safe rendering, `Cache-Control: no-store` on API |
| 13 | Testing | `tests/` (52 tests: tools, booking logic, agent flows with a scripted fake LLM, failures, post-call, LLM adapters, security, API) |
| 14 | Deployment | `Dockerfile`, `render.yaml` |

## Tests

```bash
python -m pytest -q
# or without pytest: python -m unittest discover -s tests -t .
```
`tests/test_api.py` needs FastAPI + httpx (installed by `requirements-dev.txt`); it is skipped otherwise.
The agent tests use a scripted `FakeLLM`, so they check the real tool-execution pipeline without API calls or cost.

## Deploy

Render: push to GitHub → New → Blueprint → select the repo (`render.yaml`) → set `ADMIN_PASSWORD` and `ANTHROPIC_API_KEY`.
Railway/Fly also work with the Dockerfile. The site must be served over **HTTPS** for the microphone to work (localhost is fine). SQLite needs a persistent disk; otherwise data resets on redeploy.

## Honest limitations and what I would change before real-world use

- **Voice transport**: speech-to-text and text-to-speech use the browser's Web Speech API (Chrome sends audio to Google). Production: a telephony provider (Twilio/Exotel) with streaming STT (Deepgram/Whisper) and neural TTS over WebSockets, and streaming LLM output for lower latency.
- **Transfer**: there is no live call transfer in a browser demo. `transfer_to_human` creates a high-priority callback and alerts the team.
- **Calendar and SMS are simulated**: the slots live in the database; the confirmation SMS is logged as `simulated`. Next step: Google Calendar API and an SMS gateway behind the same functions.
- **Database**: SQLite. Production: PostgreSQL with migrations (Alembic), encryption at rest, retention rules for transcripts.
- **RAG**: BM25 over ~15 chunks. Production: embeddings + vector store, document ingestion UI.
- **Auth**: single admin from env. Production: per-user accounts and roles, SSO, audit log. Rate limiting is in-memory (use Redis with multiple workers).
- **Compliance**: calls are announced as AI-assisted and transcribed; real deployments need consent handling and PII redaction policies.
