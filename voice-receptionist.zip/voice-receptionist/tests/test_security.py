import time
import unittest
from unittest import mock

import tests.helpers  # noqa: F401  (sets env)
from app import security


class SecurityTests(unittest.TestCase):
    def test_token_roundtrip(self):
        self.assertEqual(security.verify_admin_token(security.make_admin_token("admin")), "admin")

    def test_tampered_or_garbage_token_rejected(self):
        t = security.make_admin_token("admin")
        payload, sig = t.split(".")
        self.assertIsNone(security.verify_admin_token(payload + "." + sig[:-2] + "xx"))
        self.assertIsNone(security.verify_admin_token(security.make_admin_token("admin")[:-1]))
        self.assertIsNone(security.verify_admin_token("not-a-token"))
        self.assertIsNone(security.verify_admin_token(""))

    def test_expired_token_rejected(self):
        t = security.make_admin_token("admin")
        with mock.patch("app.security.time.time", return_value=time.time() + 10 * 3600):
            self.assertIsNone(security.verify_admin_token(t))

    def test_credentials(self):
        self.assertTrue(security.check_admin_credentials("admin", "test-pass"))
        self.assertFalse(security.check_admin_credentials("admin", "wrong"))
        self.assertFalse(security.check_admin_credentials("root", "test-pass"))

    def test_call_token_is_stored_hashed_and_checked(self):
        h = security.hash_token("secret-token")
        self.assertNotIn("secret-token", h)
        self.assertTrue(security.check_call_token("secret-token", h))
        self.assertFalse(security.check_call_token("other", h))
        self.assertFalse(security.check_call_token("", h))

    def test_rate_limiter(self):
        rl = security.RateLimiter()
        self.assertTrue(all(rl.allow("k", 3, 60) for _ in range(3)))
        self.assertFalse(rl.allow("k", 3, 60))
        self.assertTrue(rl.allow("other", 3, 60))


if __name__ == "__main__":
    unittest.main()
