"""End-to-end API tests through FastAPI's TestClient (needs: pip install -r requirements.txt)."""
import unittest

import tests.helpers as h

try:
    from fastapi.testclient import TestClient
    from app.main import app
    from app import agent, security
    HAVE_FASTAPI = True
except ImportError:  # pragma: no cover
    HAVE_FASTAPI = False


@unittest.skipUnless(HAVE_FASTAPI, "fastapi/httpx not installed")
class ApiTests(h.DBTestCase):
    def setUp(self):
        super().setUp()
        security.limiter.hits.clear()
        self.client = TestClient(app)

    def admin(self):
        r = self.client.post("/api/auth/login", json={"username": "admin", "password": "test-pass"})
        self.assertEqual(r.status_code, 200)
        return {"Authorization": f"Bearer {r.json()['token']}"}

    def start(self):
        r = self.client.post("/api/calls")
        self.assertEqual(r.status_code, 200)
        d = r.json()
        return d["call_id"], {"X-Call-Token": d["call_token"]}

    def test_dashboard_endpoints_require_auth(self):
        for path in ("/api/dashboard/stats", "/api/dashboard/calls", "/api/dashboard/calls/abc"):
            self.assertEqual(self.client.get(path).status_code, 401, path)
        self.assertEqual(self.client.get("/api/dashboard/stats", headers={"Authorization": "Bearer junk"}).status_code, 401)

    def test_login_wrong_password(self):
        r = self.client.post("/api/auth/login", json={"username": "admin", "password": "nope"})
        self.assertEqual(r.status_code, 401)

    def test_call_endpoints_need_the_call_token(self):
        call_id, headers = self.start()
        self.assertEqual(self.client.post(f"/api/calls/{call_id}/turn", json={"text": "hi"}).status_code, 401)
        self.assertEqual(self.client.post(f"/api/calls/{call_id}/turn", json={"text": "hi"}, headers={"X-Call-Token": "bad"}).status_code, 401)

    def test_silence_flow_and_end_call_show_up_on_dashboard(self):
        call_id, headers = self.start()
        r = self.client.post(f"/api/calls/{call_id}/turn", json={"event": "silence"}, headers=headers)
        self.assertEqual(r.status_code, 200)
        self.assertIn("still there", r.json()["reply"])
        self.assertEqual(self.client.post(f"/api/calls/{call_id}/end", headers=headers).status_code, 200)
        self.assertEqual(self.client.post(f"/api/calls/{call_id}/turn", json={"text": "hi"}, headers=headers).status_code, 409)
        admin = self.admin()
        stats = self.client.get("/api/dashboard/stats", headers=admin).json()
        self.assertEqual(stats["total_calls"], 1)
        detail = self.client.get(f"/api/dashboard/calls/{call_id}", headers=admin).json()
        self.assertNotIn("token_hash", detail["call"])
        self.assertTrue(any(t["role"] == "system" for t in detail["transcript"]))

    def test_input_validation(self):
        call_id, headers = self.start()
        r = self.client.post(f"/api/calls/{call_id}/turn", json={"text": "x" * 5000}, headers=headers)
        self.assertEqual(r.status_code, 422)
        r = self.client.post(f"/api/calls/{call_id}/turn", json={"event": "hack"}, headers=headers)
        self.assertEqual(r.status_code, 422)

    def test_security_headers_present(self):
        r = self.client.get("/health")
        self.assertEqual(r.headers["x-content-type-options"], "nosniff")
        self.assertIn("frame-ancestors 'none'", r.headers["content-security-policy"])


if __name__ == "__main__":
    unittest.main()
