"""Fill the dashboard with a few realistic sample calls (no LLM needed):  python -m scripts.seed_demo"""
from app import agent, db, post_call, tools
from app.llm import LLMError
from datetime import timedelta
from app import clock


class NoLLM:
    def complete(self, *a, **k):
        raise LLMError("seed data uses the offline summary")


def say(conn, call_id, pairs):
    for role, text in pairs:
        agent._say(conn, call_id, role, text)


def main():
    db.init_db()
    nxt = clock.now_local().date() + timedelta(days=1)
    while nxt.weekday() == 6:
        nxt += timedelta(days=1)
    with db.connect() as conn:
        c, _, _ = agent.start_call(conn)
        say(conn, c, [("user", "How much is AC servicing?"), ("assistant", "A basic AC service is five hundred and ninety nine rupees."),
                      ("user", "Book it for me, I'm Ravi in Koramangala, 98450 12345"), ("assistant", "Done, ten AM tomorrow.")])
        tools.execute_tool(conn, c, "book_appointment", {"customer_name": "Ravi Kumar", "phone": "9845012345", "service": "AC service",
                                                          "location": "Koramangala", "date": nxt.isoformat(), "time": "10:00"})
        post_call.finalize_call(conn, c, llm=NoLLM())

        c, _, _ = agent.start_call(conn)
        say(conn, c, [("user", "My kitchen tap is leaking badly, can someone come today?"), ("assistant", "I can note that. May I have your name and number?"),
                      ("user", "Meena, 90000 22222, HSR Layout")])
        tools.execute_tool(conn, c, "create_lead", {"name": "Meena S", "phone": "9000022222", "service": "plumbing", "location": "HSR Layout", "urgency": "high",
                                                    "preferred_time": "today"})
        post_call.finalize_call(conn, c, llm=NoLLM())

        c, _, _ = agent.start_call(conn)
        say(conn, c, [("user", "Your technician damaged my sink last week. I want to speak to a manager."),
                      ("assistant", "I'm sorry about that. I'll have a team member call you back right away.")])
        tools.execute_tool(conn, c, "transfer_to_human", {"reason": "Complaint: technician damaged sink", "name": "Arun P", "phone": "9876543210"})
        post_call.finalize_call(conn, c, llm=NoLLM())

        c, _, _ = agent.start_call(conn)
        post_call.finalize_call(conn, c, llm=NoLLM())   # hung up silently
    print("Seeded 4 sample calls. Open /dashboard")


if __name__ == "__main__":
    main()
