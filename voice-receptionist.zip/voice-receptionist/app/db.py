"""SQLite persistence (stdlib only). Swap `connect()` for a Postgres driver for production."""
import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path

from .config import settings

SCHEMA = """
CREATE TABLE IF NOT EXISTS customers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT, phone TEXT UNIQUE, email TEXT, location TEXT,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS calls (
  id TEXT PRIMARY KEY,
  token_hash TEXT NOT NULL,
  customer_id INTEGER REFERENCES customers(id),
  status TEXT NOT NULL DEFAULT 'active',          -- active | completed | abandoned
  started_at TEXT NOT NULL, ended_at TEXT,
  escalated INTEGER NOT NULL DEFAULT 0,
  needs_followup INTEGER NOT NULL DEFAULT 0,
  unclear_count INTEGER NOT NULL DEFAULT 0,
  llm_failures INTEGER NOT NULL DEFAULT 0,
  summary TEXT, requirement TEXT, intent TEXT, lead_priority TEXT,
  outcome TEXT, next_action TEXT, followup_recommendation TEXT
);
CREATE TABLE IF NOT EXISTS transcripts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  call_id TEXT NOT NULL REFERENCES calls(id),
  role TEXT NOT NULL,                              -- user | assistant | system
  text TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS leads (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  call_id TEXT NOT NULL UNIQUE REFERENCES calls(id),
  customer_id INTEGER REFERENCES customers(id),
  service TEXT, location TEXT, urgency TEXT, preferred_time TEXT,
  priority TEXT, status TEXT NOT NULL DEFAULT 'new', notes TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS appointments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  call_id TEXT REFERENCES calls(id),
  customer_id INTEGER REFERENCES customers(id),
  service TEXT, start_at TEXT NOT NULL, end_at TEXT NOT NULL, location TEXT,
  status TEXT NOT NULL DEFAULT 'confirmed', confirmation_code TEXT, created_at TEXT NOT NULL
);
-- one confirmed appointment per slot: the database itself prevents double booking
CREATE UNIQUE INDEX IF NOT EXISTS uq_appt_slot ON appointments(start_at) WHERE status = 'confirmed';
CREATE TABLE IF NOT EXISTS agent_actions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  call_id TEXT NOT NULL REFERENCES calls(id),
  tool TEXT NOT NULL, arguments TEXT, result TEXT, success INTEGER NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS follow_ups (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  call_id TEXT REFERENCES calls(id),
  customer_id INTEGER REFERENCES customers(id),
  type TEXT NOT NULL, reason TEXT NOT NULL, due_date TEXT,
  status TEXT NOT NULL DEFAULT 'open', created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  call_id TEXT REFERENCES calls(id),
  channel TEXT NOT NULL,                           -- team_webhook | customer_sms
  event TEXT NOT NULL, payload TEXT,
  status TEXT NOT NULL,                            -- sent | failed | logged | simulated
  error TEXT, created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_transcripts_call ON transcripts(call_id);
CREATE INDEX IF NOT EXISTS ix_actions_call ON agent_actions(call_id);
"""


@contextmanager
def connect():
    Path(settings.db_path).parent.mkdir(parents=True, exist_ok=True)
    # FastAPI may create the connection and use it on different worker threads; each connection serves one request only
    conn = sqlite3.connect(settings.db_path, timeout=15, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA journal_mode=WAL")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db() -> None:
    with connect() as conn:
        conn.executescript(SCHEMA)


def rows(conn, sql, params=()):
    return [dict(r) for r in conn.execute(sql, params).fetchall()]


def row(conn, sql, params=()):
    r = conn.execute(sql, params).fetchone()
    return dict(r) if r else None


# Table/column names below come from our own code, never from user input; values are always bound parameters.
def insert(conn, table, **vals):
    cols = ",".join(vals)
    marks = ",".join("?" * len(vals))
    return conn.execute(f"INSERT INTO {table} ({cols}) VALUES ({marks})", tuple(vals.values())).lastrowid


def update(conn, table, id_, **vals):
    sets = ", ".join(f"{k}=?" for k in vals)
    conn.execute(f"UPDATE {table} SET {sets} WHERE id=?", (*vals.values(), id_))


# ---------------------------------------------------------------- dashboard queries
def dashboard_stats(conn) -> dict:
    one = lambda sql: conn.execute(sql).fetchone()[0]
    return {
        "total_calls": one("SELECT COUNT(*) FROM calls"),
        "active_calls": one("SELECT COUNT(*) FROM calls WHERE status='active'"),
        "leads_generated": one("SELECT COUNT(*) FROM leads"),
        "appointments_created": one("SELECT COUNT(*) FROM appointments WHERE status='confirmed'"),
        "calls_needing_followup": one("SELECT COUNT(DISTINCT call_id) FROM follow_ups WHERE status='open'"),
        "escalations": one("SELECT COUNT(*) FROM calls WHERE escalated=1"),
    }


def list_calls(conn, limit=50, flag=None):
    where = {"followup": "WHERE EXISTS (SELECT 1 FROM follow_ups f WHERE f.call_id=c.id AND f.status='open')",
             "escalated": "WHERE c.escalated=1",
             "appointment": "WHERE EXISTS (SELECT 1 FROM appointments a WHERE a.call_id=c.id)"}.get(flag, "")
    return rows(conn, f"""
        SELECT c.id, c.status, c.started_at, c.ended_at, c.intent, c.outcome, c.lead_priority, c.summary,
               c.escalated, c.needs_followup, cu.name AS customer_name, cu.phone AS customer_phone
        FROM calls c LEFT JOIN customers cu ON cu.id = c.customer_id
        {where} ORDER BY c.started_at DESC, c.rowid DESC LIMIT ?""", (max(1, min(limit, 200)),))


def call_detail(conn, call_id):
    call = row(conn, "SELECT * FROM calls WHERE id=?", (call_id,))
    if not call:
        return None
    call.pop("token_hash", None)
    actions = rows(conn, "SELECT * FROM agent_actions WHERE call_id=? ORDER BY id", (call_id,))
    for a in actions:
        for k in ("arguments", "result"):
            try:
                a[k] = json.loads(a[k]) if a[k] else None
            except ValueError:
                pass
    return {
        "call": call,
        "customer": row(conn, "SELECT * FROM customers WHERE id=?", (call["customer_id"],)) if call["customer_id"] else None,
        "lead": row(conn, "SELECT * FROM leads WHERE call_id=?", (call_id,)),
        "transcript": rows(conn, "SELECT role, text, created_at FROM transcripts WHERE call_id=? ORDER BY id", (call_id,)),
        "actions": actions,
        "appointments": rows(conn, "SELECT * FROM appointments WHERE call_id=?", (call_id,)),
        "follow_ups": rows(conn, "SELECT * FROM follow_ups WHERE call_id=? ORDER BY id", (call_id,)),
        "notifications": rows(conn, "SELECT channel, event, status, error, created_at FROM notifications WHERE call_id=? ORDER BY id", (call_id,)),
    }
