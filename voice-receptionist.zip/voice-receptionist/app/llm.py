"""Provider-neutral LLM client with tool calling (stdlib only: urllib).

Neutral message format used everywhere in the app:
  {"role": "user", "content": str}
  {"role": "assistant", "content": str, "tool_calls": [{"id", "name", "args"}]}
  {"role": "tool", "tool_call_id": str, "name": str, "content": str(json)}
"""
import json
import urllib.error
import urllib.request
from dataclasses import dataclass, field

from .config import settings

TIMEOUT_S = 25


class LLMError(Exception):
    pass


@dataclass
class ToolCall:
    id: str
    name: str
    args: dict


@dataclass
class LLMResult:
    text: str = ""
    tool_calls: list = field(default_factory=list)


def _post(url, headers, payload):
    req = urllib.request.Request(url, data=json.dumps(payload).encode(), headers={"Content-Type": "application/json", "User-Agent": "Mozilla/5.0", **headers})
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT_S) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as exc:
        raise LLMError(f"LLM HTTP {exc.code}: {exc.read()[:300]!r}") from exc
    except Exception as exc:  # timeouts, DNS, bad JSON ...
        raise LLMError(f"LLM request failed: {exc}") from exc


class AnthropicClient:
    def __init__(self):
        if not settings.anthropic_api_key:
            raise LLMError("ANTHROPIC_API_KEY is not set")

    @staticmethod
    def _convert(messages):
        out = []
        for m in messages:
            if m["role"] == "tool":
                block = {"type": "tool_result", "tool_use_id": m["tool_call_id"], "content": m["content"]}
                if out and out[-1]["role"] == "user" and isinstance(out[-1]["content"], list):
                    out[-1]["content"].append(block)
                else:
                    out.append({"role": "user", "content": [block]})
            elif m["role"] == "assistant" and m.get("tool_calls"):
                blocks = [{"type": "text", "text": m["content"]}] if m.get("content") else []
                blocks += [{"type": "tool_use", "id": t["id"], "name": t["name"], "input": t["args"]} for t in m["tool_calls"]]
                out.append({"role": "assistant", "content": blocks})
            else:
                out.append({"role": m["role"], "content": m["content"]})
        return out

    def complete(self, system, messages, tools=None, max_tokens=400, temperature=0.3):
        payload = {"model": settings.anthropic_model, "max_tokens": max_tokens, "temperature": temperature,
                   "system": system, "messages": self._convert(messages)}
        if tools:
            payload["tools"] = [{"name": t["name"], "description": t["description"], "input_schema": t["parameters"]} for t in tools]
        data = _post("https://api.anthropic.com/v1/messages",
                     {"x-api-key": settings.anthropic_api_key, "anthropic-version": "2023-06-01"}, payload)
        text, calls = "", []
        for block in data.get("content", []):
            if block.get("type") == "text":
                text += block.get("text", "")
            elif block.get("type") == "tool_use":
                calls.append(ToolCall(block["id"], block["name"], block.get("input") or {}))
        return LLMResult(text.strip(), calls)


class OpenAICompatClient:
    """Works with OpenAI, Groq, OpenRouter, Gemini's OpenAI-compatible endpoint, etc."""

    def __init__(self):
        if not settings.openai_api_key:
            raise LLMError("OPENAI_API_KEY is not set")

    @staticmethod
    def _convert(system, messages):
        out = [{"role": "system", "content": system}]
        for m in messages:
            if m["role"] == "tool":
                out.append({"role": "tool", "tool_call_id": m["tool_call_id"], "content": m["content"]})
            elif m["role"] == "assistant" and m.get("tool_calls"):
                out.append({"role": "assistant", "content": m.get("content") or None,
                            "tool_calls": [{"id": t["id"], "type": "function",
                                            "function": {"name": t["name"], "arguments": json.dumps(t["args"])}}
                                           for t in m["tool_calls"]]})
            else:
                out.append({"role": m["role"], "content": m["content"]})
        return out

    def complete(self, system, messages, tools=None, max_tokens=400, temperature=0.3):
        payload = {"model": settings.openai_model, "max_tokens": max_tokens, "temperature": temperature,
                   "messages": self._convert(system, messages)}
        if tools:
            payload["tools"] = [{"type": "function", "function": {"name": t["name"], "description": t["description"],
                                                                  "parameters": t["parameters"]}} for t in tools]
            payload["tool_choice"] = "auto"
        data = _post(settings.openai_base_url.rstrip("/") + "/chat/completions",
                     {"Authorization": f"Bearer {settings.openai_api_key}"}, payload)
        try:
            msg = data["choices"][0]["message"]
        except (KeyError, IndexError) as exc:
            raise LLMError(f"Unexpected LLM response: {str(data)[:200]}") from exc
        calls = []
        for tc in msg.get("tool_calls") or []:
            try:
                args = json.loads(tc["function"].get("arguments") or "{}")
            except ValueError:
                args = {}
            calls.append(ToolCall(tc["id"], tc["function"]["name"], args if isinstance(args, dict) else {}))
        return LLMResult((msg.get("content") or "").strip(), calls)


def get_llm():
    """Returns a configured client or raises LLMError (the agent handles that as a failure case)."""
    return AnthropicClient() if settings.llm_provider == "anthropic" else OpenAICompatClient()


def llm_configured() -> bool:
    return bool(settings.anthropic_api_key if settings.llm_provider == "anthropic" else settings.openai_api_key)