import json
import unittest

from app import db, tools
from tests.helpers import DBTestCase


class SlotTests(DBTestCase):
    def test_free_slots_respect_hours_and_lead_time(self):
        with db.connect() as conn:
            r = tools.check_available_slots(conn, "x", {"date": "2026-10-05"})  # Monday, now = 08:00
            self.assertTrue(r["ok"])
            self.assertEqual(r["available_times"][0], "09:00")   # 09:00 >= 08:00 + 1h lead time
            self.assertEqual(r["available_times"][-1], "17:00")
            self.assertEqual(len(r["available_times"]), 9)

    def test_sunday_closed_returns_alternatives(self):
        with db.connect() as conn:
            r = tools.check_available_slots(conn, "x", {"date": "2026-10-11"})  # Sunday
            self.assertEqual(r["available_times"], [])
            self.assertEqual(r["next_available"][0]["date"], "2026-10-12")

    def test_invalid_and_out_of_range_dates(self):
        with db.connect() as conn:
            self.assertEqual(tools.check_available_slots(conn, "x", {"date": "tomorrow"})["error"], "invalid_date")
            self.assertEqual(tools.check_available_slots(conn, "x", {"date": "2026-10-01"})["error"], "date_out_of_range")
            self.assertEqual(tools.check_available_slots(conn, "x", {"date": "2027-01-01"})["error"], "date_out_of_range")


class BookingTests(DBTestCase):
    BOOK = dict(customer_name="Ravi Kumar", phone="98450 12345", service="AC service",
                location="Koramangala", date="2026-10-06", time="10:00")

    def test_book_success_creates_customer_lead_appointment_and_log(self):
        with db.connect() as conn:
            call_id, _ = self.new_call(conn)
            r = tools.execute_tool(conn, call_id, "book_appointment", self.BOOK)
            self.assertTrue(r["ok"], r)
            self.assertTrue(r["confirmation_code"].startswith("BH-"))
            self.assertEqual(db.row(conn, "SELECT phone FROM customers")["phone"], "+919845012345")
            lead = db.row(conn, "SELECT * FROM leads WHERE call_id=?", (call_id,))
            self.assertEqual((lead["status"], lead["priority"]), ("appointment_booked", "hot"))
            action = db.row(conn, "SELECT * FROM agent_actions WHERE tool='book_appointment'")
            self.assertEqual(action["success"], 1)
            self.assertEqual(json.loads(action["arguments"])["service"], "AC service")

    def test_booked_slot_disappears_and_double_booking_is_rejected(self):
        with db.connect() as conn:
            c1, _ = self.new_call(conn)
            c2, _ = self.new_call(conn)
            self.assertTrue(tools.execute_tool(conn, c1, "book_appointment", self.BOOK)["ok"])
            free = tools.check_available_slots(conn, c2, {"date": "2026-10-06"})["available_times"]
            self.assertNotIn("10:00", free)
            r = tools.execute_tool(conn, c2, "book_appointment", {**self.BOOK, "customer_name": "Sita", "phone": "9000011111"})
            self.assertFalse(r["ok"])
            self.assertEqual(r["error"], "slot_taken")
            self.assertTrue(r["alternatives"])

    def test_validation_failures(self):
        cases = {
            "invalid_phone": {"phone": "12345"},
            "outside_service_area": {"location": "Mysuru"},
            "invalid_slot": {"time": "10:30"},
            "date_out_of_range": {"date": "2026-10-03", "time": "10:00"},   # a past Saturday
            "missing_fields": {"customer_name": ""},
        }
        with db.connect() as conn:
            call_id, _ = self.new_call(conn)
            for expected, patch in cases.items():
                r = tools.execute_tool(conn, call_id, "book_appointment", {**self.BOOK, **patch})
                self.assertFalse(r["ok"], expected)
                self.assertEqual(r["error"], expected)
            self.assertEqual(db.row(conn, "SELECT COUNT(*) AS n FROM appointments")["n"], 0)

    def test_sunday_booking_rejected(self):
        with db.connect() as conn:
            call_id, _ = self.new_call(conn)
            r = tools.execute_tool(conn, call_id, "book_appointment", {**self.BOOK, "date": "2026-10-11"})
            self.assertEqual(r["error"], "invalid_slot")


class LeadFollowUpEscalationTests(DBTestCase):
    def test_create_lead_upserts_and_reports_missing_fields(self):
        with db.connect() as conn:
            call_id, _ = self.new_call(conn)
            r = tools.execute_tool(conn, call_id, "create_lead", {"name": "Meena", "phone": "+91 90000 22222", "service": "plumbing"})
            self.assertTrue(r["ok"])
            self.assertEqual(r["priority"], "cold")
            self.assertIn("location", r["still_missing"])
            r2 = tools.execute_tool(conn, call_id, "create_lead", {"name": "Meena", "phone": "9000022222", "service": "plumbing",
                                                                    "location": "HSR", "urgency": "high"})
            self.assertEqual(r2["lead_id"], r["lead_id"])  # same lead updated, not duplicated
            self.assertEqual(r2["priority"], "hot")
            self.assertEqual(db.row(conn, "SELECT COUNT(*) AS n FROM leads")["n"], 1)
            self.assertEqual(db.row(conn, "SELECT COUNT(*) AS n FROM customers")["n"], 1)

    def test_create_lead_rejects_bad_phone(self):
        with db.connect() as conn:
            call_id, _ = self.new_call(conn)
            r = tools.execute_tool(conn, call_id, "create_lead", {"name": "A B", "phone": "123", "service": "x"})
            self.assertEqual(r["error"], "invalid_phone")
            self.assertEqual(db.row(conn, "SELECT COUNT(*) AS n FROM leads")["n"], 0)

    def test_follow_up_needs_phone_then_succeeds(self):
        with db.connect() as conn:
            call_id, _ = self.new_call(conn)
            r = tools.execute_tool(conn, call_id, "create_follow_up", {"reason": "Wants a quote"})
            self.assertEqual(r["error"], "need_phone")
            r = tools.execute_tool(conn, call_id, "create_follow_up", {"reason": "Wants a quote", "phone": "9876543210", "name": "Arun"})
            self.assertTrue(r["ok"])
            self.assertEqual(r["due_date"], "2026-10-06")  # next business day after Monday
            self.assertEqual(self.call_row(conn, call_id)["needs_followup"], 1)

    def test_transfer_to_human_escalates_once_and_notifies(self):
        with db.connect() as conn:
            call_id, _ = self.new_call(conn)
            r = tools.execute_tool(conn, call_id, "transfer_to_human", {"reason": "Angry about last visit"})
            self.assertTrue(r["ok"])
            self.assertFalse(r["callback_number_on_file"])
            r2 = tools.execute_tool(conn, call_id, "transfer_to_human", {"reason": "same", "phone": "9876543210", "name": "Arun"})
            self.assertTrue(r2["already_escalated"] and r2["callback_number_on_file"])
            self.assertEqual(db.row(conn, "SELECT COUNT(*) AS n FROM follow_ups WHERE type='human_callback'")["n"], 1)
            self.assertEqual(self.call_row(conn, call_id)["escalated"], 1)
            self.assertEqual(db.row(conn, "SELECT event FROM notifications")["event"], "escalation")

    def test_tool_crash_is_contained_logged_and_rolled_back(self):
        from unittest import mock
        with db.connect() as conn:
            call_id, _ = self.new_call(conn)
            with mock.patch.dict(tools.TOOLS, {"create_lead": lambda *a, **k: 1 / 0}):
                r = tools.execute_tool(conn, call_id, "create_lead", {"name": "A B", "phone": "9876543210", "service": "x"})
            self.assertEqual(r["error"], "tool_failure")
            self.assertEqual(db.row(conn, "SELECT success FROM agent_actions WHERE tool='create_lead'")["success"], 0)

    def test_unknown_tool(self):
        with db.connect() as conn:
            call_id, _ = self.new_call(conn)
            self.assertEqual(tools.execute_tool(conn, call_id, "delete_everything", {})["error"], "unknown_tool")


class HelperTests(unittest.TestCase):
    def test_phone_normalisation(self):
        n = tools.normalize_phone
        self.assertEqual(n("98450 12345"), "+919845012345")
        self.assertEqual(n("+91-98450-12345"), "+919845012345")
        self.assertEqual(n("09845012345"), "+919845012345")
        self.assertEqual(n("nine eight four five zero one two three four five"), "+919845012345")
        self.assertIsNone(n("1234567890"))   # must start 6-9
        self.assertIsNone(n(""))

    def test_service_area_matching(self):
        self.assertEqual(tools.match_service_area("hsr"), "HSR Layout")
        self.assertEqual(tools.match_service_area("Near Indira Nagar metro"), "Indiranagar")
        self.assertIsNone(tools.match_service_area("Mysuru"))


if __name__ == "__main__":
    unittest.main()
