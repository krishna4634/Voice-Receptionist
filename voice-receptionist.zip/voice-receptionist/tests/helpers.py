import os
import tempfile
import unittest
from datetime import datetime
from unittest import mock

os.environ["APP_ENV"] = "test"
os.environ["ADMIN_USERNAME"] = "admin"
os.environ["ADMIN_PASSWORD"] = "test-pass"
os.environ["SECRET_KEY"] = "x" * 40
os.environ.pop("WEBHOOK_URL", None)

from app import agent, db  # noqa: E402
from app.llm import LLMResult, ToolCall  # noqa: E402

NOW = datetime(2026, 10, 5, 8, 0)  # Monday 08:00 (fixed so slot logic is deterministic)


class FakeLLM:
    """Scripted LLM: each item is an LLMResult or an Exception to raise. Records what it was sent."""

    def __init__(self, *script):
        self.script, self.calls = list(script), []

    def complete(self, system, messages, tools=None, **kw):
        self.calls.append({"system": system, "messages": list(messages)})
        item = self.script.pop(0)
        if isinstance(item, Exception):
            raise item
        return item


def tool(_tool_name, **args):
    return LLMResult("", [ToolCall(f"id_{_tool_name}", _tool_name, args)])


def say(text):
    return LLMResult(text)


class DBTestCase(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        os.environ["DB_PATH"] = os.path.join(self._tmp.name, "test.db")
        db.init_db()
        self._clock = mock.patch("app.clock.now_local", return_value=NOW)
        self._clock.start()
        self.addCleanup(self._clock.stop)
        self.addCleanup(self._tmp.cleanup)

    def new_call(self, conn):
        call_id, token, _ = agent.start_call(conn)
        return call_id, token

    def call_row(self, conn, call_id):
        return db.row(conn, "SELECT * FROM calls WHERE id=?", (call_id,))
