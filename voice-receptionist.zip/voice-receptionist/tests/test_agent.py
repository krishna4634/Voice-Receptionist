import unittest

from app import agent, db, post_call
from app.llm import LLMError
from tests.helpers import DBTestCase, FakeLLM, say, tool

BOOK = dict(customer_name="Ravi Kumar", phone="9845012345", service="AC service", location="Koramangala",
            date="2026-10-06", time="10:00")


class AgentFlowTests(DBTestCase):
    def turn(self, conn, call_id, text, llm, **kw):
        return agent.handle_turn(conn, self.call_row(conn, call_id), text, llm=llm, **kw)

    def test_full_booking_conversation_with_tool_calls(self):
        """The demo scenario: info question -> details -> slots -> booking -> summary -> follow-up automation."""
        with db.connect() as conn:
            call_id, _ = self.new_call(conn)

            llm = FakeLLM(say("AC service is five hundred and ninety nine rupees. Would you like to book?"))
            r = self.turn(conn, call_id, "How much does AC servicing cost?", llm)
            self.assertIn("ninety nine", r["reply"])
            # retrieval happened BEFORE answering: pricing chunk is inside the system prompt the LLM saw
            self.assertIn("Rs 599", llm.calls[0]["system"])

            llm = FakeLLM(tool("create_lead", name="Ravi Kumar", phone="9845012345", service="AC service"),
                          say("Thanks Ravi. Which area are you in?"))
            r = self.turn(conn, call_id, "Yes. I'm Ravi Kumar, my number is 9845012345", llm)
            self.assertEqual(r["actions"], [{"tool": "create_lead", "ok": True}])

            llm = FakeLLM(tool("check_available_slots", date="2026-10-06"),
                          tool("book_appointment", **BOOK),
                          say("Done. You're booked for Tuesday at ten AM. Your code is on its way."))
            r = self.turn(conn, call_id, "Koramangala, tomorrow at ten works", llm)
            self.assertEqual([a["tool"] for a in r["actions"]], ["check_available_slots", "book_appointment"])
            # the tool RESULT was fed back to the LLM (that is what makes this real tool calling)
            fed_back = [m for m in llm.calls[2]["messages"] if m["role"] == "tool"]
            self.assertEqual(len(fed_back), 2)
            self.assertEqual(db.row(conn, "SELECT COUNT(*) AS n FROM appointments")["n"], 1)
            # state refreshed in the prompt after the booking
            self.assertIn("AC service", llm.calls[2]["system"])

            intel = FakeLLM(say('{"summary":"Ravi booked an AC service for Tuesday 10 AM in Koramangala.",'
                                '"customer_requirement":"AC service","intent":"appointment_booking","lead_priority":"hot",'
                                '"outcome":"appointment_booked","next_action":"Technician visit Tuesday 10:00",'
                                '"followup_recommendation":"Send reminder the evening before."}'))
            call = post_call.finalize_call(conn, call_id, llm=intel)
            self.assertEqual((call["status"], call["outcome"], call["lead_priority"]), ("completed", "appointment_booked", "hot"))
            events = [n["event"] for n in db.rows(conn, "SELECT event FROM notifications")]
            self.assertEqual(sorted(events), ["appointment_booked", "appointment_confirmation", "new_lead"])
            self.assertEqual(db.row(conn, "SELECT status FROM notifications WHERE channel='customer_sms'")["status"], "simulated")
            roles = [t["role"] for t in db.rows(conn, "SELECT role FROM transcripts WHERE call_id=?", (call_id,))]
            self.assertEqual(roles.count("user"), 3)

    def test_unknown_question_gets_no_invented_context(self):
        with db.connect() as conn:
            call_id, _ = self.new_call(conn)
            llm = FakeLLM(say("I don't have that detail. Shall I arrange a callback?"))
            self.turn(conn, call_id, "Do you do solar panel installation?", llm)
            self.assertIn("Do NOT answer factual business questions from your own knowledge", llm.calls[0]["system"])

    def test_human_request_creates_escalation_not_a_fake_resolution(self):
        with db.connect() as conn:
            call_id, _ = self.new_call(conn)
            llm = FakeLLM(tool("transfer_to_human", reason="Caller wants a person", name="Arun", phone="9876543210"),
                          say("I've asked a team member to call you back on that number."))
            r = self.turn(conn, call_id, "I want to talk to a real person", llm)
            self.assertTrue(r["escalated"])
            self.assertEqual(db.row(conn, "SELECT type FROM follow_ups")["type"], "human_callback")
            done = post_call.finalize_call(conn, call_id, llm=FakeLLM(say("not json")))  # LLM garbage -> heuristic fallback
            self.assertEqual(done["outcome"], "escalated_to_human")
            self.assertEqual(done["needs_followup"], 1)

    def test_tool_failure_is_reported_to_llm_and_conversation_continues(self):
        with db.connect() as conn:
            call_id, _ = self.new_call(conn)
            llm = FakeLLM(tool("book_appointment", **{**BOOK, "location": "Mysuru"}),
                          say("Sorry, we don't serve Mysuru. Shall I note a follow-up?"))
            r = self.turn(conn, call_id, "Book me in, I'm in Mysuru", llm)
            self.assertEqual(r["actions"], [{"tool": "book_appointment", "ok": False}])
            tool_msg = [m for m in llm.calls[1]["messages"] if m["role"] == "tool"][0]["content"]
            self.assertIn("outside_service_area", tool_msg)

    def test_markdown_is_stripped_from_spoken_reply(self):
        with db.connect() as conn:
            call_id, _ = self.new_call(conn)
            r = self.turn(conn, call_id, "hello there friend", FakeLLM(say("**Sure!** We open at *nine*.")))
            self.assertEqual(r["reply"], "Sure! We open at nine.")


class FailureHandlingTests(DBTestCase):
    def turn(self, conn, call_id, text, llm=None, **kw):
        return agent.handle_turn(conn, self.call_row(conn, call_id), text, llm=llm, **kw)

    def test_silence_then_unclear_then_auto_escalation(self):
        with db.connect() as conn:
            call_id, _ = self.new_call(conn)
            r1 = self.turn(conn, call_id, "", event="silence")
            r2 = self.turn(conn, call_id, "", event="unclear")
            self.assertFalse(r1["end_call"] or r2["end_call"])
            self.assertIn("still there", r1["reply"])
            r3 = self.turn(conn, call_id, "", event="silence")
            self.assertTrue(r3["end_call"] and r3["escalated"])
            self.assertEqual(self.call_row(conn, call_id)["escalated"], 1)

    def test_successful_speech_resets_the_unclear_counter(self):
        with db.connect() as conn:
            call_id, _ = self.new_call(conn)
            self.turn(conn, call_id, "", event="silence")
            self.turn(conn, call_id, "what are your hours", FakeLLM(say("Nine to six.")))
            self.assertEqual(self.call_row(conn, call_id)["unclear_count"], 0)

    def test_llm_outage_retries_then_apologises_then_creates_followup(self):
        with db.connect() as conn:
            call_id, _ = self.new_call(conn)
            r = self.turn(conn, call_id, "hello there friend", FakeLLM(LLMError("boom"), LLMError("boom")))
            self.assertIn("technical problem", r["reply"])
            self.assertFalse(r["end_call"])
            r = self.turn(conn, call_id, "hello are you there", FakeLLM(LLMError("boom"), LLMError("boom")))
            self.assertTrue(r["end_call"])
            fu = db.row(conn, "SELECT type FROM follow_ups")
            self.assertEqual(fu["type"], "system_failure")   # created even though we never got a phone number

    def test_retry_recovers_from_a_single_transient_failure(self):
        with db.connect() as conn:
            call_id, _ = self.new_call(conn)
            r = self.turn(conn, call_id, "hello there friend", FakeLLM(LLMError("blip"), say("Hello! How can I help?")))
            self.assertEqual(r["reply"], "Hello! How can I help?")
            self.assertEqual(self.call_row(conn, call_id)["llm_failures"], 0)

    def test_llm_dies_after_booking_still_confirms_truthfully(self):
        with db.connect() as conn:
            call_id, _ = self.new_call(conn)
            llm = FakeLLM(tool("book_appointment", **BOOK), LLMError("down"), LLMError("down"))
            r = self.turn(conn, call_id, "book tuesday ten", llm)
            self.assertIn("confirmed", r["reply"])
            self.assertIn("BH-", r["reply"])

    def test_missing_api_key_is_handled_like_any_llm_failure(self):
        import os
        old = os.environ.pop("ANTHROPIC_API_KEY", None)
        try:
            with db.connect() as conn:
                call_id, _ = self.new_call(conn)
                r = self.turn(conn, call_id, "hello there friend")  # no fake -> real get_llm() -> LLMError
                self.assertIn("technical problem", r["reply"])
        finally:
            if old:
                os.environ["ANTHROPIC_API_KEY"] = old


class PostCallTests(DBTestCase):
    def test_hang_up_without_speaking_is_abandoned_and_needs_no_llm(self):
        with db.connect() as conn:
            call_id, _ = self.new_call(conn)
            call = post_call.finalize_call(conn, call_id, llm=FakeLLM())
            self.assertEqual((call["status"], call["outcome"]), ("abandoned", "abandoned"))

    def test_qualified_lead_without_booking_gets_followup_and_webhook_notification(self):
        with db.connect() as conn:
            call_id, _ = self.new_call(conn)
            agent.handle_turn(conn, self.call_row(conn, call_id), "I need a plumber", llm=FakeLLM(
                tool("create_lead", name="Meena S", phone="9000022222", service="plumbing", location="HSR", urgency="high"),
                say("Noted. Our team will call you.")))
            post_call.finalize_call(conn, call_id, llm=FakeLLM(say("```json\n" + '{"summary":"s","customer_requirement":"plumbing","intent":"lead_enquiry",'
                                                             '"lead_priority":"hot","outcome":"lead_captured","next_action":"Call back","followup_recommendation":"Call today"}' + "\n```")))
            fu = db.row(conn, "SELECT * FROM follow_ups WHERE call_id=?", (call_id,))
            self.assertEqual(fu["type"], "callback")
            self.assertEqual(self.call_row(conn, call_id)["needs_followup"], 1)
            self.assertIn("new_lead", [n["event"] for n in db.rows(conn, "SELECT event FROM notifications")])

    def test_finalize_is_idempotent(self):
        with db.connect() as conn:
            call_id, _ = self.new_call(conn)
            agent.handle_turn(conn, self.call_row(conn, call_id), "I need a plumber", llm=FakeLLM(
                tool("create_lead", name="Meena S", phone="9000022222", service="plumbing", location="HSR"), say("ok")))
            post_call.finalize_call(conn, call_id, llm=FakeLLM(say("garbage")))
            n1 = db.row(conn, "SELECT COUNT(*) AS n FROM notifications")["n"]
            post_call.finalize_call(conn, call_id, llm=FakeLLM())
            self.assertEqual(db.row(conn, "SELECT COUNT(*) AS n FROM notifications")["n"], n1)

    def test_webhook_failure_does_not_break_the_call_record(self):
        import os
        from unittest import mock
        os.environ["WEBHOOK_URL"] = "http://127.0.0.1:9/hook"
        try:
            with db.connect() as conn, mock.patch.object(post_call, "_http_post", side_effect=OSError("refused")):
                call_id, _ = self.new_call(conn)
                agent.handle_turn(conn, self.call_row(conn, call_id), "need AC", llm=FakeLLM(
                    tool("create_lead", name="Meena S", phone="9000022222", service="AC", location="HSR"), say("ok")))
                call = post_call.finalize_call(conn, call_id, llm=FakeLLM(say("garbage")))
                self.assertEqual(call["status"], "completed")
                self.assertEqual(db.row(conn, "SELECT status FROM notifications WHERE event='new_lead'")["status"], "failed")
        finally:
            os.environ.pop("WEBHOOK_URL", None)


if __name__ == "__main__":
    unittest.main()
