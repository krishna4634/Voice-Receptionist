"""Time helpers. Tests patch `now_local` so appointment logic is deterministic."""
from datetime import datetime, timedelta, timezone

from .config import settings

try:
    from zoneinfo import ZoneInfo
except ImportError:  # pragma: no cover
    ZoneInfo = None


def now_utc_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def now_local() -> datetime:
    """Current business-local time as a naive datetime (appointments are stored in business-local time)."""
    try:
        tz = ZoneInfo(settings.business_tz)
    except Exception:  # tzdata missing (e.g. Windows without `tzdata`) -> fixed IST offset
        tz = timezone(timedelta(hours=5, minutes=30))
    return datetime.now(tz).replace(tzinfo=None)
